<?php
// 총합
function sum($argList){
    $sum = 0;
    for ($i=0; $i < count($argList); $i++){
        $sum += $argList[$i];
    }
    return $sum;
}
// 평균
function average($argList){
    return sum($argList) / count($argList);
}
// 정렬
function sort_bubble(&$argList, $arglsAscendingOrder){
    for ($i = 0; $i < count($argList); $i++){
        for ($j = 0; $j < count($argList) - $i - 1; $j++){
            if ($arglsAscendingOrder){ // true  : 오름차순
                if ($argList[$i] < $argList[$j]){
                    $change        = $argList[$j];
                    $argList[$j]   = $argList[$j+1];
                    $argList[$j+1] = $change;
                }
            } else{                    // false : 내림차순
                if ($argList[$i] > $argList[$j]){
                    $change        = $argList[$j];
                    $argList[$j]   = $argList[$j+1];
                    $argList[$j+1] = $change;
                }
            }

        }
    }
    return $argList;
}
// 중간값
function median($argList){
    sort_bubble($argList, true);
    if (count($argList)%2==0){
        $med = ($argList[count($argList) / 2]
                + $argList[(count($argList) / 2) + 1]) / 2;
    } else{
        $med = (Interger)($argList[count($argList) / 2] / 2) + 1;
    }
    return $med;
}