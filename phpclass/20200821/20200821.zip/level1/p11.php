<?php

include  'level2\test.php';

echo value."<br>";
test();