<?php
namespace{
    const value = 18;
    function test() {
        echo 'MyProject\level1\level2\test 1<br>';
    }
}
