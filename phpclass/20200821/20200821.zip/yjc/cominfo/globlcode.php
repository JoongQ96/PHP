<?php
namespace {
    const test = "test at globalcode";

    class gtest {
        static function prt() { echo "globalcode<br>"; }
    }
}