<?php
namespace yjc\cominfo\jclass;

class test {
    static function prt() { echo "jclass<br>"; }
}
const value = "jclass";