<?php
echo "write_comment_process 페이지 입니다.";

$commentUser = $_GET['commentUser'];
echo "commentUser : ".$commentUser;